##' @slot u0 The initial state vector (\eqn{N_c \times N_n}) with the
##'     number of individuals in each compartment in every node.
