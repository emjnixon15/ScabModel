##' @param legend a logical indicating whether a legend for the
##'     compartments should be added to the plot. A legend is not
##'     drawn for a prevalence plot.
