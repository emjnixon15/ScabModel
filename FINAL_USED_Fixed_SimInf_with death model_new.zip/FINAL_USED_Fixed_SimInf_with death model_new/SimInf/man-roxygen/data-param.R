##' @param data A \code{data.frame} holding the time series data.
