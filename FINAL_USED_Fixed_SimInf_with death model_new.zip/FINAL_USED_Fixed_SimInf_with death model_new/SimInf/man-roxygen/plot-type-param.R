##' @param type The type of plot to draw. The default \code{type =
##'     "s"} draws stair steps. See base plot for other values.
