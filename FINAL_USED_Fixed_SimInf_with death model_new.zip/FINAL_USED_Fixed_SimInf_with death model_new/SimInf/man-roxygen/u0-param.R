##' @param u0 A \code{data.frame} with the initial state in each node
##'     (see \sQuote{Details}).
