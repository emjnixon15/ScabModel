##' @param phi A numeric vector with the initial environmental
##'     infectious pressure in each node. Will be repeated to the
##'     length of nrow(u0). Default is NULL which gives 0 in each
##'     node.
