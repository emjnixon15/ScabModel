##' @param verbose prints diagnostic messages when \code{TRUE}. The
##'     default is to retrieve the global option \code{verbose} and
##'     use \code{FALSE} if it is not set.
