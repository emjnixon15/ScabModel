##' @param npart An integer with the number of particles (> 1) to use
##'     at each timestep.
