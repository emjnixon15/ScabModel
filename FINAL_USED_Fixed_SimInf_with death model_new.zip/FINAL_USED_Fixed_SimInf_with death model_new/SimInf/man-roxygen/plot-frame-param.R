##' @param frame.plot a logical indicating whether a box should be
##'     drawn around the plot.
