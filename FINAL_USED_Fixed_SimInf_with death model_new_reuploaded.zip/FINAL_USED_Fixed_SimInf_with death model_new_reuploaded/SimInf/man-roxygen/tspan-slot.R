##' @slot tspan A vector of increasing time points where the state of
##'     each node is to be returned.
