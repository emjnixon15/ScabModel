##' @param events a \code{data.frame} with the scheduled events, see
##'     \code{\link{SimInf_model}}.
