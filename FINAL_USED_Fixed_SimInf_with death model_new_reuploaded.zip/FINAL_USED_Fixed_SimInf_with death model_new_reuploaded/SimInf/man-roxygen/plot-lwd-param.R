##' @param lwd The line width. Default is \code{2}.
