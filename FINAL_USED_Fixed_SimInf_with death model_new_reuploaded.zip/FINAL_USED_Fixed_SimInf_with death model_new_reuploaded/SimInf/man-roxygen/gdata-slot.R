##' @slot gdata A numeric vector with global data that is common to
##'     all nodes.  The global data vector is passed as an argument to
##'     the transition rate functions and the post time step function.
