##' @param index Indices specifying the nodes to include when plotting
##'     data. Plot one line for each node. Default (\code{index =
##'     NULL}) is to extract data from all nodes and plot the median
##'     count for the specified compartments.
