##' @param index Indices specifying the subset of nodes to include in
##'     the calculation of the prevalence. Default is \code{index =
##'     NULL}, which includes all nodes.
